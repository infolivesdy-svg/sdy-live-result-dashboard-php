'use strict';
const tbody = document.getElementById('results');
const status = document.getElementById('status');
let busy = false;
async function refreshResults() {
  if (busy) return;
  busy = true;
  try {
    const response = await fetch('/api.php', { cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const payload = await response.json();
    if (payload.kind !== 'demo' || !Array.isArray(payload.results)) throw new Error('Format data tidak valid');
    const fragment = document.createDocumentFragment();
    for (const item of payload.results) {
      const row = document.createElement('tr');
      for (const value of [item.date, item.period, item.number]) {
        const cell = document.createElement('td');
        cell.textContent = String(value ?? '');
        row.appendChild(cell);
      }
      fragment.appendChild(row);
    }
    tbody.replaceChildren(fragment);
    status.textContent = `Data simulasi diperbarui: ${new Date().toLocaleTimeString('id-ID')}`;
  } catch (error) {
    status.textContent = `Gagal memuat data: ${error.message}`;
  } finally {
    busy = false;
  }
}
refreshResults();
setInterval(() => { if (!document.hidden) refreshResults(); }, 60000);
